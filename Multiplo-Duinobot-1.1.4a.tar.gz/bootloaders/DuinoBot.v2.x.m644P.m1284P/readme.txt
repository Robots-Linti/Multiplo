DuinoBot 2.3 Bootloader for ATmega644P and ATmega1284P
------------------------------------------------------

To compile for ATmega644P, run makedb23_644.bat
Target File: optiboot_DB23_644p.hex
Fuses:
LF = 0xFF
HF = 0xDE
EF = 0xFD


To compile for ATmega1284P, run makedb23_1284.bat
Target File: optiboot_DB23_1284p.hex
Fuses:
LF = 0xFF
HF = 0xDE
EF = 0xFD

Compiled with: WinAVR-20120120 (http://sourceforge.net/projects/winavr/files/WinAVR/)
Final size: 1 KByte.
