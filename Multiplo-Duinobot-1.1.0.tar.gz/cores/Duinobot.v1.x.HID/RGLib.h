#ifndef RGLib__h
#define RGLib__h

//By now, this is the only thing here.
//See:
//http://www.arduino.cc/cgi-bin/yabb2/YaBB.pl?num=1284655356

const int nonAssigned_pin = -1; //Negative pins don't exist, and int is signed.

#endif
